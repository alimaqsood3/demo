import requests
import json

API_KEY = "GlobalITService_default_secret"
MIROTALK_URL = "http://localhost:3010/api/v1/join"

headers = {
    "authorization": API_KEY,
    "Content-Type": "application/json",
}

data = {
    "room": "test",
    "name": "GlobalITService",
    "audio": "true",
    "video": "true",
    "notify": "true",
}

response = requests.post(
    MIROTALK_URL,
    headers=headers,
    json=data,
)

print("Status code:", response.status_code)
data = json.loads(response.text)
print("join:", data["join"])
